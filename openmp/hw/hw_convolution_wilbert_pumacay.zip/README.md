

Results of using the parallel version :

	Using 4 threads with no compiler optimizations :
	 * Serial-Time   = 3.88098
	 * Parallel-Time = 1.07227
	 * Speedup 		 = 3.61942
	 * Efficienty 	 = 0.90486

	Using 4 threads with -O3 compiler optimizations :
	 * Serial-Time   = 1.24023
	 * Parallel-Time = 0.34375
	 * Speedup 		 = 3.60794
	 * Efficienty 	 = 0.90199
